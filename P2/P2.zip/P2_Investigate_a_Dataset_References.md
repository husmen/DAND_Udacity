* [Pandas GroupBy User Guide](https://pandas.pydata.org/pandas-docs/stable/user_guide/groupby.html)
* [Seaborn Boxplot](https://seaborn.pydata.org/generated/seaborn.boxplot.html)
* [Seaborn Distributions](https://seaborn.pydata.org/tutorial/distributions.html)